import java.util.*;
class Main
{
    public static void main(String[] args)
    {
        Scanner obj=new Scanner(System.in);
        String s=obj.nextLine();
        int l=0;
        int h=s.length()-1;
        boolean isPalindrome=true;
        while(l<=h)
        {
            if(s.charAt(l)!=s.charAt(h))
            {
                isPalindrome=false;
                break;
            }
            l++;
            h--;
            
        }
        if(isPalindrome)
        {
            System.out.println("It is a palindrome");
            
        }
        else
        {
            System.out.println("Not a palindrome");
        }
    }
}