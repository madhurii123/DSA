import java.util.*;

class Main {

    
    static void merge(int[] arr, int l, int m, int r) {
        int n = r - l + 1;
        int[] temp = new int[n];

        int i = l;      
        int j = m + 1;  
        int k = 0;      

      
        while (i <= m && j <= r) {
            if (arr[i] <= arr[j]) {
                temp[k] = arr[i];
                i++;
            } else {
                temp[k] = arr[j];
                j++;
            }
            k++;
        }

        // Copy remaining elements from left subarray
        while (i <= m) {
            temp[k] = arr[i];
            i++;
            k++;
        }

        // Copy remaining elements from right subarray
        while (j <= r) {
            temp[k] = arr[j];
            j++;
            k++;
        }

        // Copy sorted elements back to original array
    for (i = 0; i < n; i = i + 1) {
            arr[l + i] = temp[i];
        }
       }

    // Recursive merge sort
    static void mergeSort(int[] arr, int l, int r) {
        if (l < r) {
            int m = (l + r) / 2;

            mergeSort(arr, l, m);      // Sort left half
            mergeSort(arr, m + 1, r);  // Sort right half

            merge(arr, l, m, r);       // Merge sorted halves
        }
    }

    public static void main(String[] args) {
        int[] arr = {38, 27, 43, 10};

        mergeSort(arr, 0, arr.length - 1);

        System.out.println(Arrays.toString(arr));
    }
}